export { default as DetectionContainer } from './Detection.container';
