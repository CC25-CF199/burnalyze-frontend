function Example() {
  return (
    <>
      <h1 className="font-bold text-primaryBlue">Example BurnAlyze</h1>
    </>
  );
}

export default Example;
