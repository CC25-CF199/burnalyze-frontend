
import HeroSection from '@/components/sections/HeroSection';
import FeatureCards from '@/components/sections/FeatureCards';
import FactSection from '@/components/sections/FactSection';
import TestimonialSection from '@/components/sections/TestimonialSection';
import FAQSection from '@/components/sections/FAQSection';
import FooterSection from '@/components/sections/FooterSection';
import Navbar from '@/components/organisms/Navbar';
import SideDrawer from '@/components/organisms/Drawer';

import { Box } from '@mui/material';
import { useState } from 'react';

const LandingContainer = () => {
  const [drawerOpen, setDrawerOpen] = useState(false);

  const toggleDrawer = (open) => (event) => {
    if (event.type === 'keydown' && (event.key === 'Tab' || event.key === 'Shift')) return;
    setDrawerOpen(open);
  };

  return (
    <Box sx={{ minHeight: '100vh', backgroundColor: '#f8fafc' }}>
      <SideDrawer open={drawerOpen} toggleDrawer={toggleDrawer} />
      <Navbar toggleDrawer={toggleDrawer} />

      <HeroSection />
      <FeatureCards />
      <FactSection />
      <TestimonialSection />
      <FAQSection />
      <FooterSection />
    </Box>
  );
};

export default LandingContainer;
