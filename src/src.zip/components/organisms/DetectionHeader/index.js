export { default as DetectionHeader } from './DetectionHeader.component';
