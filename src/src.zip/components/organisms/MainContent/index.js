export { default as MainContent } from './MainContent.component';
