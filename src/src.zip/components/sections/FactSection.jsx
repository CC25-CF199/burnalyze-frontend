import { Box, Typography } from '@mui/material';
import LocalFireDepartmentIcon from '@mui/icons-material/LocalFireDepartment';
import ShieldIcon from '@mui/icons-material/Shield';
import GroupsIcon from '@mui/icons-material/Groups';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';

const facts = [
  {
    text: '70% kasus luka bakar rumah tangga terjadi akibat air panas, minyak goreng atau api dapur.',
    arrow: 'down',
    iconType: 'fire'
  },
  {
    text: 'Pertolongan pertama yang tepat dapat mengurangi kerusakan jaringan dan mempercepat penyembuhan.',
    arrow: 'up',
    iconType: 'shield'
  },
  {
    text: 'Deteksi dini tingkat keparahan luka bakar membantu menentukan penanganan yang optimal.',
    arrow: 'up',
    iconType: 'people'
  }
];

const FactSection = () => {
  return (
    <Box sx={{ py: 3 }}>
      {facts.map((fact, index) => {
        const IconComponent =
          fact.iconType === 'fire' ? LocalFireDepartmentIcon :
          fact.iconType === 'shield' ? ShieldIcon :
          GroupsIcon;

        return (
          <Box
            key={index}
            sx={{
              border: '1px solid #00c3ff',
              borderRadius: 2,
              p: 3,
              mb: 2,
              backgroundColor: '#ffffff',
              boxShadow: '0 1px 3px rgba(0,0,0,0.05)'
            }}
          >
            <Box sx={{ display: 'flex', justifyContent: 'center', mb: 2 }}>
              <IconComponent sx={{ fontSize: 32, color: '#00c3ff' }} />
            </Box>

            <Typography
              variant="body2"
              sx={{
                textAlign: 'center',
                color: '#00c3ff',
                fontSize: '0.875rem',
                fontWeight: 500,
                lineHeight: 1.5
              }}
            >
              {fact.text}
            </Typography>

            <Box sx={{ textAlign: 'center', mt: 1 }}>
              {fact.arrow === 'down' ? (
                <KeyboardArrowDownIcon sx={{ fontSize: 28, color: '#00c3ff' }} />
              ) : (
                <KeyboardArrowUpIcon sx={{ fontSize: 28, color: '#00c3ff' }} />
              )}
            </Box>
          </Box>
        );
      })}
    </Box>
  );
};

export default FactSection;
