// File: src/components/sections/FAQSection.jsx
import { Box, Typography, Accordion, AccordionSummary, AccordionDetails } from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';

const faqList = [
  {
    question: 'Apa itu BurnAlyze?',
    answer: 'BurnAlyze adalah platform digital berbasis kecerdasan buatan yang dirancang untuk membantu mendeteksi dan menganalisis luka bakar melalui teknologi computer vision. Platform ini memberikan bantuan cepat dalam mengidentifikasi tingkat keparahan luka bakar dan memberikan panduan penanganan yang tepat.'
  },
  {
    question: 'Apakah BurnAlyze dapat digunakan secara gratis',
    answer: 'Benar. BurnAlyze sepenuhnya gratis untuk digunakan. Kami berkomitmen untuk memberikan akses mudah dan terjangkau kepada semua orang untuk mendapatkan bantuan deteksi luka bakar yang akurat.'
  },
  {
    question: 'Apakah BurnAlyze bisa membantu penanganan pertama luka bakar',
    answer: 'Benar! BurnAlyze berkomitmen memberikan panduan pertolongan pertama yang tepat berdasarkan tingkat keparahan luka bakar yang terdeteksi. Aplikasi akan memberikan langkah-langkah penanganan awal yang aman sebelum mendapatkan bantuan medis profesional.'
  },
  {
    question: 'Kegiatan seperti apa yang sering menyebabkan luka bakar sampai harus lebih diperhatikan?',
    answer: 'Luka bakar dapat terjadi dari berbagai aktivitas sehari-hari seperti memasak (minyak panas, air mendidih), penggunaan alat elektronik yang panas, terpapar sinar matahari berlebihan, atau kontak dengan bahan kimia. Kegiatan di dapur dan aktivitas outdoor perlu perhatian khusus.'
  }
];

const FAQSection = () => {
  return (
    <Box sx={{ py: 4, textAlign: 'center' }}>
      <Box
        sx={{
          backgroundColor: '#f3f3f3',
          borderRadius: '16px',
          p: 3,
          maxWidth: 500,
          mx: 'auto'
        }}
      >
        <Typography
          variant="h6"
          sx={{
            fontSize: '1.125rem',
            fontWeight: 600,
            color: '#222222',
            mb: 3
          }}
        >
          Find answer of your <Box component="span" sx={{ color: '#00c3ff' }}>questions</Box>
        </Typography>

        <Box sx={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
          {faqList.map((item, index) => (
            <Accordion
              key={index}
              sx={{
                backgroundColor: 'white',
                borderRadius: '12px !important',
                boxShadow: 'none',
                '&:before': { display: 'none' },
                '&.Mui-expanded': { margin: 0 }
              }}
              defaultExpanded={index === 0}
            >
              <AccordionSummary
                expandIcon={<ExpandMoreIcon sx={{ color: '#555555' }} />}
                sx={{ '& .MuiAccordionSummary-content': { margin: '12px 0' } }}
              >
                <Typography
                  sx={{
                    fontSize: '1rem',
                    fontWeight: 600,
                    color: '#1f1f1f'
                  }}
                >
                  {item.question}
                </Typography>
              </AccordionSummary>
              <AccordionDetails sx={{ pt: 0 }}>
                <Typography
                  sx={{
                    fontSize: '0.875rem',
                    color: '#555555',
                    lineHeight: 1.6
                  }}
                >
                  {item.answer}
                </Typography>
              </AccordionDetails>
            </Accordion>
          ))}
        </Box>
      </Box>
    </Box>
  );
};

export default FAQSection;
