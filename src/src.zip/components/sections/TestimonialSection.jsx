import { Box, Typography } from '@mui/material';

const testimonials = [
  {
    quote: 'Sangat membantu saat keadaan darurat!',
    text: 'Web luar biasa! Saya panik saat adik saya terkena luka bakar, dan BurnAlyze bisa membantu mendeteksi tingkat lukanya hanya dari foto. Panduan pertolongannya jelas dan langsung bisa saya terapkan. Sangat direkomendasikan!',
    rating: 5,
    align: 'left'
  },
  {
    quote: 'Teknologi yang sangat bermanfaat',
    text: 'Sebagai ibu rumah tangga, saya sangat terbantu. Anak-anak sering tidak sengaja terkena benda panas, dan BurnAlyze membantu saya menentukan apakah cukup ditangani di rumah atau perlu ke dokter.',
    rating: 5,
    align: 'right'
  },
  {
    quote: 'Cocok bagi mahasiswa kesehatan atau relawan',
    text: 'Sebagai mahasiswa keperawatan, saya pakai ini untuk latihan dan belajar mengidentifikasi luka bakar. Membantu banget buat pengenalan awal sebelum praktik langsung.',
    rating: 5,
    align: 'left'
  },
  {
    quote: 'Mudah diakses, edukatif',
    text: 'Saya suka karena bukan hanya deteksi luka, tapi juga ada edukasi lengkap tentang jenis luka dan pertolongan pertama. Cocok buat masyarakat umum.',
    rating: 4,
    align: 'right'
  }
];

const TestimonialSection = () => {
  return (
    <Box sx={{ backgroundColor: '#f9f9f9', py: 4, textAlign: 'center' }}>
      <Typography
        variant="h5"
        sx={{
          fontSize: '1.25rem',
          fontWeight: 700,
          mb: 4
        }}
      >
        <Box component="span" sx={{ color: '#222' }}>Why </Box>
        <Box component="span" sx={{ color: '#00c3ff' }}>BurnAlyze</Box>
        <Box component="span" sx={{ color: '#222' }}>?</Box>
      </Typography>

      <Box sx={{ maxWidth: 800, mx: 'auto' }}>
        {testimonials.map((item, index) => (
          <Box
            key={index}
            sx={{
              display: 'flex',
              justifyContent: item.align === 'left' ? 'flex-start' : 'flex-end',
              mb: 3
            }}
          >
            <Box
              sx={{
                backgroundColor: '#ffffff',
                borderRadius: '16px',
                boxShadow: '0 4px 10px rgba(0, 0, 0, 0.1)',
                p: 2.5,
                maxWidth: 400,
                textAlign: 'left'
              }}
            >
              <Typography
                sx={{
                  color: '#00c3ff',
                  fontWeight: 700,
                  fontSize: '1rem',
                  mb: 1
                }}
              >
                "{item.quote}"
              </Typography>

              <Typography
                sx={{
                  color: '#333',
                  fontSize: '0.875rem',
                  fontWeight: 400,
                  lineHeight: 1.5,
                  mb: 2
                }}
              >
                {item.text}
              </Typography>

              <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'flex-end', mt: 2 }}>
                <Typography sx={{ fontSize: '0.875rem', color: '#ffc107', mr: 1 }}>
                  {'⭐'.repeat(item.rating)}
                </Typography>
                <Typography sx={{ fontSize: '0.875rem', color: '#333' }}>
                  ({item.rating}/5)
                </Typography>
              </Box>
            </Box>
          </Box>
        ))}
      </Box>
    </Box>
  );
};

export default TestimonialSection;
