
import { Box, Typography } from '@mui/material';

const HeroSection = () => {
  return (
    <Box 
      sx={{
        background: 'linear-gradient(180deg, #00c3ff 0%, #00dffb 60%, #ffffff 100%)',
        borderRadius: '0 0 20px 20px',
        pt: 3,
        pb: 4,
        textAlign: 'center',
        boxShadow: '0 4px 10px rgba(0,0,0,0.1)',
        position: 'relative'
      }}
    >
      <Box sx={{ maxWidth: 480, mx: 'auto', px: 2 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 1, mb: 2 }}>
          <Box
            sx={{
              width: 16,
              height: 16,
              backgroundColor: '#ffdc3b',
              borderRadius: '50%',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: '10px'
            }}
          >
            ✓
          </Box>
          <Typography 
            variant="body2"
            sx={{ color: '#ffffff', fontSize: '0.875rem' }}
          >
            Selamat Datang di <Box component="span" sx={{ color: '#ffdc3b', fontWeight: 600 }}>BurnAlyze</Box>!
          </Typography>
        </Box>

        <Typography 
          variant="h4" 
          component="h1"
          sx={{ 
            color: '#ffffff',
            fontWeight: 700,
            fontSize: '1.75rem',
            lineHeight: 1.3,
            mb: 1
          }}
        >
          Deteksi cerdas dan klasifikasi luka bakar dengan cepat.
        </Typography>

        <Typography 
          variant="body2" 
          sx={{ 
            color: '#ffffff', 
            fontSize: '0.875rem',
            fontWeight: 400,
            lineHeight: 1.6,
            maxWidth: '85%',
            mx: 'auto',
            mb: 2
          }}
        >
          Melalui deteksi kamera, BurnAlyze membantu Anda mengenali jenis luka bakar dan memberikan langkah penanganan awal yang tepat.
        </Typography>

        <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 2 }}>
          <Box
            component="img"
            src="/landing1.png"
            alt="Doctor with phone"
            sx={{
              height: { xs: 180, sm: 240 },
              position: 'absolute',
              right: 16,
              bottom: -30,
              zIndex: 3
            }}
          />
        </Box>
      </Box>
    </Box>
  );
};

export default HeroSection;