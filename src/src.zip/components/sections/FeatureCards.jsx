import { Box, Typography } from '@mui/material';
import detectionIcon from '@/assets/icons/detection.png';
import historyIcon from '@/assets/icons/history.png';
import educationIcon from '@/assets/icons/education.png';

const features = [
  { icon: detectionIcon, title: 'Deteksi' },
  { icon: historyIcon, title: 'Riwayat' },
  { icon: educationIcon, title: 'Edukasi' }
];

const FeatureCards = () => {
  return (
    <Box
      sx={{
        display: 'flex',
        justifyContent: 'space-between',
        backgroundColor: 'white',
        px: 2,
        py: 2.5,
        borderRadius: '20px',
        mt: -3,
        mx: 'auto',
        maxWidth: 360,
        boxShadow: '0 8px 24px rgba(0,0,0,0.08)',
        position: 'relative',
        zIndex: 2
      }}
    >
      {features.map((feature, index) => (
        <Box
          key={index}
          sx={{
            flex: 1,
            textAlign: 'center',
            cursor: 'pointer',
            '&:hover': {
              transform: 'scale(1.05)',
              transition: 'all 0.2s ease-in-out',
              boxShadow: '0 4px 10px rgba(0, 195, 255, 0.3)'
            }
          }}
        >
          <Box
            component="img"
            src={feature.icon}
            alt={feature.title}
            sx={{
              height: 28,
              width: 'auto',
              margin: 'auto',
              mb: 1,
              objectFit: 'contain'
            }}
          />
          <Typography
            variant="body2"
            sx={{
              fontSize: '0.85rem',
              fontWeight: 500,
              color: 'text.primary'
            }}
          >
            {feature.title}
          </Typography>
        </Box>
      ))}
    </Box>
  );
};

export default FeatureCards;
