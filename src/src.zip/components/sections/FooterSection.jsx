import { Box, Typography, Divider, Link, IconButton } from '@mui/material';
import FacebookIcon from '@mui/icons-material/Facebook';
import InstagramIcon from '@mui/icons-material/Instagram';
import XIcon from '@mui/icons-material/X';
import YouTubeIcon from '@mui/icons-material/YouTube';

const FooterSection = () => {
  return (
    <Box
      sx={{
        backgroundColor: '#1e1f23',
        color: '#f5f5f5',
        py: 4,
        px: 3,
        width: '100vw',
        ml: 'calc(-50vw + 50%)'
      }}
    >
      {/* Main Footer Content */}
      <Box
        sx={{
          display: 'flex',
          justifyContent: 'space-between',
          flexWrap: 'wrap',
          gap: 4,
          mb: 3
        }}
      >
        {/* Branding and Links */}
        <Box>
          <Typography variant="h6" sx={{ fontSize: '1rem', fontWeight: 700, mb: 2 }}>
            BurnAlyze
          </Typography>
          <Box sx={{ display: 'flex', flexDirection: 'column', gap: 1 }}>
            <Link
              href="#"
              sx={{
                fontSize: '0.875rem',
                color: '#f5f5f5',
                textDecoration: 'underline',
                textDecorationColor: '#f5f5f5',
                '&:hover': {
                  color: '#ffffff'
                }
              }}
            >
              Tentang Kami
            </Link>
            <Link
              href="#"
              sx={{
                fontSize: '0.875rem',
                color: '#f5f5f5',
                '&:hover': {
                  color: '#ffffff',
                  textDecoration: 'underline'
                }
              }}
            >
              Fitur
            </Link>
            <Link
              href="#"
              sx={{
                fontSize: '0.875rem',
                color: '#f5f5f5',
                '&:hover': {
                  color: '#ffffff',
                  textDecoration: 'underline'
                }
              }}
            >
              Edukasi
            </Link>
          </Box>
        </Box>

        {/* Social Media */}
        <Box>
          <Typography variant="h6" sx={{ fontSize: '1rem', fontWeight: 700, mb: 2 }}>
            Media Sosial
          </Typography>
          <Box sx={{ display: 'flex', gap: 2 }}>
            {[FacebookIcon, InstagramIcon, XIcon, YouTubeIcon].map((Icon, idx) => (
              <IconButton
                key={idx}
                sx={{
                  color: '#f5f5f5',
                  p: 0,
                  '&:hover': {
                    color: '#ffffff'
                  }
                }}
              >
                <Icon sx={{ fontSize: 20 }} />
              </IconButton>
            ))}
          </Box>
        </Box>
      </Box>

      <Divider sx={{ borderColor: '#d9d9d9', opacity: 0.3, my: 3 }} />

      {/* Copyright */}
      <Typography
        sx={{
          fontSize: '0.75rem',
          color: '#f5f5f5',
          opacity: 0.8,
          textAlign: 'left'
        }}
      >
        Hak Cipta © 2025 BurnAlyze
      </Typography>
    </Box>
  );
};

export default FooterSection;
