export { default as ProtectedResult } from './ProtectedResult';
