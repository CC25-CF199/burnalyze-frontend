export { default as RegistrationForm } from './RegistrationForm.component';
