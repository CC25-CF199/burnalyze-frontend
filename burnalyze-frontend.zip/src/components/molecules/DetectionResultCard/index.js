export { default as DetectionResultCard } from './DetectionResultCard.component';
