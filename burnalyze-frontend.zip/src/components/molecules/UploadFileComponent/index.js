export { default as UploadFileComponent } from './UploadFile.component';
