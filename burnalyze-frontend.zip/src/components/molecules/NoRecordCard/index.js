export { default as NoRecordCardComponent } from './NoRecordCard.component';
