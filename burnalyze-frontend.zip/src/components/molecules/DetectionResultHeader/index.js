export { default as DetectionResultHeader } from './DetectionResultHeader.component';
