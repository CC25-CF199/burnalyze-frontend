export { default as DetectionResultAccordion } from './DetectionResultAccordion.component';
