export { default as FileUploadComponent } from './FileUpload.component';
