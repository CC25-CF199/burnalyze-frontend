export { default as DragFileUploadComponent } from './DragFileUpload.component';
