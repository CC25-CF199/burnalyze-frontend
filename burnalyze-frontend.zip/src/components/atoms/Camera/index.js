export { default as CameraComponent } from './Camera.component';
