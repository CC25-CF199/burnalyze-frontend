export { default as InputLabelComponent } from './InputLabel.component';
