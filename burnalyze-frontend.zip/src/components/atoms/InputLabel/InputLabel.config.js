const styleConfig = {
  regular: {
    className: 'font-bold',
  },
  email: {
    className: 'text-xs md:text-sm lg:text-md font-medium',
  },
  password: {
    className: 'text-xs md:text-sm lg:text-md font-medium',
  },
};

export { styleConfig };
