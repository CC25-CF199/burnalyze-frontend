export { default as FormInputComponent } from './FormInput.component';
