export { default as InputComponent } from './Input.component';
