export { default as RegisterContainer } from './Register.container';
