export { default as DetectionHistoryContainer } from './DetectionHistory.container';
