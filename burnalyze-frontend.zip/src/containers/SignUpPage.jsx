import React from 'react';
import { Link } from 'react-router-dom';

const SignUpPage = () => {
  return (
    <div className="min-h-screen bg-gray-900 flex items-center justify-center">
      <div className="bg-white p-10 rounded-lg shadow-md w-full max-w-sm">
        <div className="flex flex-col items-center mb-6">
          <img src="/burnalyze-logo.png" alt="BurnAlyze Logo" className="h-14 mb-2" />
        </div>

        <h2 className="text-center text-gray-700 text-sm mb-4">Create your Account</h2>

        <form className="space-y-4">
          <input
            type="text"
            placeholder="Username"
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#00a3d4]"
          />
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="First Name"
              className="w-1/2 px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#00a3d4]"
            />
            <input
              type="text"
              placeholder="Last Name"
              className="w-1/2 px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#00a3d4]"
            />
          </div>
          <input
            type="email"
            placeholder="Email"
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#00a3d4]"
          />
          <input
            type="password"
            placeholder="Password"
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#00a3d4]"
          />
          <input
            type="password"
            placeholder="Confirm Password"
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#00a3d4]"
          />
          <button
            type="submit"
            className="w-full bg-[#00a3d4] hover:bg-[#0094c8] text-white font-semibold py-2 rounded-md transition"
          >
            Sign Up
          </button>
        </form>

        <div className="my-6 flex items-center justify-between">
          <span className="border-b w-1/5 lg:w-1/4"></span>
          <span className="text-xs text-center text-gray-500 uppercase">or sign up with</span>
          <span className="border-b w-1/5 lg:w-1/4"></span>
        </div>

        <div className="flex justify-center gap-4">
          <button className="border p-2 rounded-md">
            <img src="/google-icon.png" alt="Google" className="h-5 w-5" />
          </button>
          <button className="border p-2 rounded-md">
            <img src="/facebook-icon.png" alt="Facebook" className="h-5 w-5" />
          </button>
        </div>

        <p className="text-center text-sm text-gray-500 mt-6">
          Already have an account?{' '}
          <Link to="/login" className="text-[#00a3d4] font-medium hover:underline">
            Sign In
          </Link>
        </p>
      </div>
    </div>
  );
};

export default SignUpPage;
