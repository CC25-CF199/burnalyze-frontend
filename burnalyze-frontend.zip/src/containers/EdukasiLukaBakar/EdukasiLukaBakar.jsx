import React from 'react';

const EdukasiLukaBakar = () => {
  return (
    <div className="max-w-xl mx-auto px-4 py-8 text-gray-800">
      <h1 className="text-2xl font-bold text-center mb-2">Edukasi Luka Bakar</h1>
      <p className="text-center text-sm text-gray-600 mb-6">
        Kenali gejala, penyebab, dan penanganan luka bakar secara tepat.
      </p>

      <section className="bg-white p-4 rounded-lg shadow mb-4">
        <h2 className="text-lg font-semibold mb-2">📘 Pengertian Luka Bakar</h2>
        <p>Luka bakar adalah kerusakan jaringan kulit ...</p>
      </section>

      {/* tambahkan bagian lain seperti Penyebab, Gejala, Diagnosa, dll */}
    </div>
  );
};

export default EdukasiLukaBakar;
