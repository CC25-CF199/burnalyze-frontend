export { default as EdukasiLukaBakar } from './EdukasiLukaBakar.container';
