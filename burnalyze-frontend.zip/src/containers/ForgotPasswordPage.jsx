import React from 'react';
import { Link } from 'react-router-dom';

const ForgotPasswordPage = () => {
  return (
    <div className="min-h-screen bg-gray-900 flex items-center justify-center">
      <div className="bg-white p-10 rounded-lg shadow-md w-full max-w-sm">
        <div className="flex flex-col items-center mb-6">
          <img src="/burnalyze-logo.png" alt="BurnAlyze Logo" className="h-14 mb-2" />
        </div>

        <h2 className="text-center text-gray-700 text-sm mb-4">Reset your Password</h2>

        <form className="space-y-4">
          <input
            type="email"
            placeholder="Email"
            className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-[#00a3d4]"
          />
          <button
            type="submit"
            className="w-full bg-[#00a3d4] hover:bg-[#0094c8] text-white font-semibold py-2 rounded-md transition"
          >
            Send Reset password
          </button>
        </form>

        <p className="text-center text-sm text-gray-500 mt-6">
          Remembered your password?{' '}
          <Link to="/login" className="text-[#00a3d4] font-medium hover:underline">
            Sign In
          </Link>
        </p>
      </div>
    </div>
  );
};

export default ForgotPasswordPage;
