export { default as DetectionResultContainer } from './DetectionResult.container';
